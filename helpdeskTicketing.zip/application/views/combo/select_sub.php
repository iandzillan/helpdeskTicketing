<div class="form-group">
	<?php echo form_dropdown('id_sub_kategori', $dd_sub_kategori, $id_sub_kategori, ' class="form-control"'); ?>
</div>