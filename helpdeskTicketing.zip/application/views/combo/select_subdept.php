<div class="form-group">
	<?php echo form_dropdown('id_bagian_departemen', $dd_bagian_departemen, $id_bagian_departemen, ' class="form-control"'); ?>
</div>